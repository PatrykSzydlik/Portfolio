#ifndef strukt_h
#define strukt_h


int pop(t_stos *stos,int *dana);
void push(t_stos *stos,int dana);
void print(t_stos stos);
int reverse(t_stos *stos);
int dubluj(t_stos *stos);
void fullprint(t_stos stos);


#endif
