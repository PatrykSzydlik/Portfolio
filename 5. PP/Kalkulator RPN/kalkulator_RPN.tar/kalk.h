#ifndef kalk_h
#define kalk_h

int potega(t_stos *stos);
int pierw_kwadr(t_stos *stos);
int dodaj(t_stos *stos);
int odejmij(t_stos *stos);
int pomnoz(t_stos *stos);
int podziel(t_stos *stos);
int silnia(t_stos *stos);
void bledy(int komunikat);


#endif
